export class addStockRequest {

    companycode?: string
    stockPrice?: number

}