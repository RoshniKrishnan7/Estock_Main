import { Time } from "@angular/common";

export class stock {
    companyStockId?: number;
    companyId?: number;
    stockPrice?: number;
    startDate?: Date;
    endDate?: Date;
}
     